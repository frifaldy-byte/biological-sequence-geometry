BIOLOGICAL SEQUENCE GEOMETRY
FINAL RESEARCH PACKAGE
=============================================

Package generated: 2026-11-18 15:16:30

SOURCE NOTEBOOK
---------------
PaperBioLieAlgebra.ipynb

PACKAGE STRUCTURE
-----------------

01_CODE/
    Phase_1.py
    Phase_2.py
    Phase_3.py
    Phase_4B.py
    PaperBioLieAlgebra.ipynb

02_GRAPHS/
    All phase figures are stored directly in this folder.
    There are no phase-specific subfolders.

03_TABLES/
    CSV output tables.

04_RESULTS_AND_LOGS/
    TXT and LOG result files.

05_DOCUMENTATION/
    README.txt
    MANIFEST.csv

GRAPH COLLECTION
----------------

Phase_1: 5 unique PNG file(s)
Phase_2: 5 unique PNG file(s)
Phase_3: 4 unique PNG file(s)
Phase_4B: 4 unique PNG file(s)

Total unique PNG files: 18

Exact duplicate PNG files skipped: 0

GRAPH SOURCE POLICY
-------------------

Existing phase output folders are the primary source of figures.

Embedded notebook images are used only when the corresponding
phase output folder contains no PNG files.

Exact duplicate PNG files are detected using SHA-256 hashes.
Only one copy of each exact file is retained.

SCIENTIFIC COMPUTATION
----------------------

This packaging operation does not rerun the simulations.
It does not modify the mathematical model, parameters,
numerical results, or scientific source notebook.

The exported Python files are extracted from the saved
notebook source cells.

IMPORTANT
---------

The ZIP validation checks archive integrity.
It does not independently validate scientific correctness,
figure interpretation, or the numerical model.

Please retain the original notebook as the primary
editable research source.
